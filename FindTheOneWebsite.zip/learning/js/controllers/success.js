myApp.controller('SuccessController', ['$scope', function($scope){
    	$scope.message = "Welcome to Successs";
}])